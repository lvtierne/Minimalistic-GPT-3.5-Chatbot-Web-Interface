// Event listener for form submission
document.getElementById('question-form').addEventListener('submit', async function(e) {
    e.preventDefault(); // Prevent the default form submission

    const question = document.getElementById('question').value; // Get the question from the input field
    const responseDiv = document.getElementById('response'); // Get the div to display the response
    responseDiv.textContent = 'Thinking...'; // Show a loading message

    try {
        // Send the question to the server
        const response = await fetch('/ask', {
            method: 'POST', // Use POST method
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded', // Set the content type
            },
            body: new URLSearchParams({ question: question }) // Send the question as form data
        });

        // Handle the server response
        if (response.ok) {
            const data = await response.json(); // Parse the JSON response
            responseDiv.innerHTML = `<p><strong>Q:</strong> ${data.question}</p><p><strong>A:</strong> ${data.answer}</p>`; // Display the question and answer
        } else {
            responseDiv.textContent = 'An error occurred. Please try again.'; // Show error message if response is not ok
        }
    } catch (error) {
        responseDiv.textContent = 'An error occurred. Please try again.'; // Show error message if fetch fails
    }
});
